import { c as clientExports, j as jsxRuntimeExports, R as React, A as App } from './chunks/App-CF7hGKhV.js';

const root = document.getElementById("root");
clientExports.createRoot(root).render(
  /* @__PURE__ */ jsxRuntimeExports.jsx(React.StrictMode, { children: /* @__PURE__ */ jsxRuntimeExports.jsx(App, {}) })
);
