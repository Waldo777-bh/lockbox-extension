const DASHBOARD_URL = "https://dashboard.yourlockbox.dev";
const API_BASE_URL = `${DASHBOARD_URL}/api`;
const SIGN_IN_URL = `${DASHBOARD_URL}/sign-in`;
const CACHE_TTL_MS = 5 * 60 * 1e3;
const RECENT_KEYS_COUNT = 5;
const REVEAL_DURATION_MS = 5e3;
const COPY_FEEDBACK_MS = 2e3;
const STORAGE_KEYS = {
  AUTH_TOKEN: "lockbox_auth_token",
  USER_DATA: "lockbox_user_data",
  CACHE_DATA: "lockbox_cache_data",
  RECENT_KEYS: "lockbox_recent_keys"
};
const API_KEY_FIELD_SELECTORS = [
  'input[name*="api_key" i]',
  'input[name*="apikey" i]',
  'input[name*="api-key" i]',
  'input[name*="secret_key" i]',
  'input[name*="secret-key" i]',
  'input[name*="secretkey" i]',
  'input[name*="access_token" i]',
  'input[name*="access-token" i]',
  'input[name*="accesstoken" i]',
  'input[name*="auth_token" i]',
  'input[name*="token" i]',
  'input[id*="api_key" i]',
  'input[id*="apikey" i]',
  'input[id*="api-key" i]',
  'input[id*="secret_key" i]',
  'input[id*="secret-key" i]',
  'input[id*="access_token" i]',
  'input[id*="auth_token" i]',
  'input[placeholder*="api key" i]',
  'input[placeholder*="api_key" i]',
  'input[placeholder*="secret key" i]',
  'input[placeholder*="access token" i]',
  'input[placeholder*="sk-" i]',
  'input[placeholder*="pk_" i]',
  'input[aria-label*="api key" i]',
  'input[aria-label*="secret key" i]',
  'input[aria-label*="access token" i]'
];

export { API_BASE_URL as A, CACHE_TTL_MS as C, DASHBOARD_URL as D, RECENT_KEYS_COUNT as R, STORAGE_KEYS as S, COPY_FEEDBACK_MS as a, REVEAL_DURATION_MS as b, SIGN_IN_URL as c, API_KEY_FIELD_SELECTORS as d };
