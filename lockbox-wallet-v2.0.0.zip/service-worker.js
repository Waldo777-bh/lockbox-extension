const STORAGE_KEYS = {
  VAULT: "lockbox_vault",
  CONFIG: "lockbox_config",
  STATUS: "lockbox_status",
  ACCOUNT: "lockbox_account",
  DERIVED_KEY: "lockbox_derived_key",
  RECENT_KEYS: "lockbox_recent_keys"
};
let lastActivity = Date.now();
let autoLockMinutes = 15;
chrome.runtime.onInstalled.addListener(() => {
  chrome.alarms.create("lockbox-autolock-check", { periodInMinutes: 1 });
  chrome.alarms.create("lockbox-badge-update", { periodInMinutes: 60 });
  if (chrome.sidePanel) {
    chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: false }).catch(() => {
    });
  }
  chrome.contextMenus.create({
    id: "lockbox-sidepanel",
    title: "Open Lockbox in Side Panel",
    contexts: ["action"]
  });
});
chrome.contextMenus.onClicked.addListener((info, tab) => {
  if (info.menuItemId === "lockbox-sidepanel" && chrome.sidePanel && tab?.windowId) {
    chrome.sidePanel.open({ windowId: tab.windowId }).catch(() => {
    });
  }
});
chrome.alarms.onAlarm.addListener(async (alarm) => {
  if (alarm.name === "lockbox-autolock-check") {
    await checkAutoLock();
  } else if (alarm.name === "lockbox-badge-update") {
    await updateBadge();
  }
});
async function checkAutoLock() {
  try {
    const config = await chrome.storage.local.get(STORAGE_KEYS.CONFIG);
    const walletConfig = config[STORAGE_KEYS.CONFIG];
    autoLockMinutes = walletConfig?.autoLockMinutes ?? 15;
    if (autoLockMinutes === 0) return;
    const elapsed = (Date.now() - lastActivity) / 6e4;
    if (elapsed >= autoLockMinutes) {
      const session = await chrome.storage.session.get(STORAGE_KEYS.DERIVED_KEY);
      if (session[STORAGE_KEYS.DERIVED_KEY]) {
        await chrome.storage.session.remove(STORAGE_KEYS.DERIVED_KEY);
        await chrome.storage.local.set({ [STORAGE_KEYS.STATUS]: "locked" });
        await updateBadge();
      }
    }
  } catch {
  }
}
chrome.runtime.onInstalled.addListener(function setupContextMenus() {
  chrome.contextMenus.removeAll(() => {
    chrome.contextMenus.create({
      id: "lockbox-root",
      title: "Lockbox: Paste API Key",
      contexts: ["editable"]
    });
    chrome.contextMenus.create({
      id: "lockbox-search",
      parentId: "lockbox-root",
      title: "Search all keys...",
      contexts: ["editable"]
    });
    chrome.contextMenus.create({
      id: "lockbox-separator",
      parentId: "lockbox-root",
      type: "separator",
      contexts: ["editable"]
    });
    chrome.contextMenus.create({
      id: "lockbox-open",
      parentId: "lockbox-root",
      title: "Open Lockbox",
      contexts: ["editable"]
    });
  });
  updateBadge();
});
chrome.contextMenus.onClicked.addListener(async (info, tab) => {
  if (info.menuItemId === "lockbox-open" || info.menuItemId === "lockbox-search") {
    try {
      await chrome.action.openPopup();
    } catch {
    }
    return;
  }
});
chrome.omnibox.onInputStarted.addListener(() => {
  chrome.omnibox.setDefaultSuggestion({
    description: "Search Lockbox keys... Type a service or key name"
  });
});
chrome.omnibox.onInputChanged.addListener(async (text, suggest) => {
  if (!text.trim()) return;
  suggest([
    {
      content: `search:${text}`,
      description: `Search for "<match>${text}</match>" in Lockbox`
    }
  ]);
});
chrome.omnibox.onInputEntered.addListener(async (text) => {
  try {
    await chrome.action.openPopup();
  } catch {
    const url = chrome.runtime.getURL("popup.html");
    chrome.tabs.create({ url });
  }
});
async function updateBadge() {
  try {
    const session = await chrome.storage.session.get(STORAGE_KEYS.DERIVED_KEY);
    const isUnlocked = !!session[STORAGE_KEYS.DERIVED_KEY];
    if (!isUnlocked) {
      await chrome.action.setBadgeText({ text: "" });
      await chrome.action.setTitle({ title: "Lockbox — Locked" });
      return;
    }
    await chrome.action.setBadgeBackgroundColor({ color: "#00d87a" });
    await chrome.action.setBadgeText({ text: "" });
    await chrome.action.setTitle({ title: "Lockbox — Unlocked" });
  } catch {
  }
}
function base64ToBuffer(b64) {
  const binary = atob(b64);
  const bytes = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
  return bytes.buffer;
}
function bufferToBase64(buf) {
  const bytes = new Uint8Array(buf);
  let binary = "";
  for (let i = 0; i < bytes.length; i++) binary += String.fromCharCode(bytes[i]);
  return btoa(binary);
}
async function decryptVault(vault, derivedKeyB64) {
  const keyMaterial = base64ToBuffer(derivedKeyB64);
  const hmacKey = await crypto.subtle.importKey(
    "raw",
    keyMaterial,
    { name: "HMAC", hash: "SHA-256" },
    false,
    ["verify"]
  );
  const signatureBuf = base64ToBuffer(vault.hmac);
  const dataBuf = new TextEncoder().encode(vault.ciphertext);
  const valid = await crypto.subtle.verify("HMAC", hmacKey, signatureBuf, dataBuf);
  if (!valid) throw new Error("Invalid key");
  const ivBuf = new Uint8Array(base64ToBuffer(vault.iv));
  const ciphertextBuf = new Uint8Array(base64ToBuffer(vault.ciphertext));
  const tagBuf = new Uint8Array(base64ToBuffer(vault.tag));
  const combined = new Uint8Array(ciphertextBuf.length + tagBuf.length);
  combined.set(ciphertextBuf);
  combined.set(tagBuf, ciphertextBuf.length);
  const aesKey = await crypto.subtle.importKey(
    "raw",
    keyMaterial,
    { name: "AES-GCM" },
    false,
    ["decrypt"]
  );
  const decrypted = await crypto.subtle.decrypt(
    { name: "AES-GCM", iv: ivBuf, tagLength: 128 },
    aesKey,
    combined
  );
  return JSON.parse(new TextDecoder().decode(decrypted));
}
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (!message?.type) return;
  switch (message.type) {
    case "LOCKBOX_ACTIVITY":
      lastActivity = Date.now();
      break;
    case "LOCKBOX_LOCK":
      (async () => {
        await chrome.storage.session.remove(STORAGE_KEYS.DERIVED_KEY);
        await chrome.storage.local.set({ [STORAGE_KEYS.STATUS]: "locked" });
        await updateBadge();
      })();
      break;
    case "LOCKBOX_GET_STATUS":
      (async () => {
        try {
          const [status, session] = await Promise.all([
            chrome.storage.local.get(STORAGE_KEYS.STATUS),
            chrome.storage.session.get(STORAGE_KEYS.DERIVED_KEY)
          ]);
          sendResponse({
            status: status[STORAGE_KEYS.STATUS] || "uninitialized",
            isUnlocked: !!session[STORAGE_KEYS.DERIVED_KEY]
          });
        } catch {
          sendResponse({ status: "uninitialized", isUnlocked: false });
        }
      })();
      return true;
    case "LOCKBOX_GET_ALL_KEYS":
      (async () => {
        try {
          const session = await chrome.storage.session.get(STORAGE_KEYS.DERIVED_KEY);
          const derivedKey = session[STORAGE_KEYS.DERIVED_KEY];
          if (!derivedKey) {
            sendResponse({ keys: [], locked: true });
            return;
          }
          const stored = await chrome.storage.local.get(STORAGE_KEYS.VAULT);
          const vault = stored[STORAGE_KEYS.VAULT];
          if (!vault) {
            sendResponse({ keys: [], locked: false });
            return;
          }
          const wallet = await decryptVault(vault, derivedKey);
          const allKeys = wallet.vaults.flatMap(
            (v) => v.keys.map((k) => ({
              id: k.id,
              service: k.service,
              name: k.name,
              value: k.value,
              vaultName: v.name
            }))
          );
          sendResponse({ keys: allKeys, locked: false });
          lastActivity = Date.now();
        } catch {
          sendResponse({ keys: [], locked: true });
        }
      })();
      return true;
    case "LOCKBOX_COPY_TO_CLIPBOARD":
      if (message.payload?.value) {
        (async () => {
          try {
            const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
            if (tab?.id) {
              chrome.tabs.sendMessage(
                tab.id,
                { type: "LOCKBOX_COPY_TO_CLIPBOARD", payload: { value: message.payload.value } },
                () => {
                  if (chrome.runtime.lastError) {
                  }
                }
              );
            }
          } catch {
          }
        })();
      }
      break;
    case "LOCKBOX_PASTE_KEY":
      if (message.payload?.value) {
        (async () => {
          try {
            const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
            if (tab?.id) {
              chrome.tabs.sendMessage(
                tab.id,
                { type: "LOCKBOX_PASTE_KEY", payload: { value: message.payload.value } },
                () => {
                  if (chrome.runtime.lastError) {
                  }
                }
              );
            }
          } catch {
          }
        })();
      }
      break;
    case "LOCKBOX_KEY_CAPTURED":
      (async () => {
        try {
          const session = await chrome.storage.session.get(STORAGE_KEYS.DERIVED_KEY);
          const derivedKey = session[STORAGE_KEYS.DERIVED_KEY];
          if (!derivedKey || !message.payload) {
            sendResponse?.({ success: false, reason: "locked" });
            return;
          }
          const stored = await chrome.storage.local.get(STORAGE_KEYS.VAULT);
          const vault = stored[STORAGE_KEYS.VAULT];
          if (!vault) return;
          const wallet = await decryptVault(vault, derivedKey);
          const defaultVault = wallet.vaults[0];
          if (!defaultVault) return;
          const newKey = {
            id: crypto.randomUUID(),
            service: message.payload.service || "unknown",
            name: message.payload.name || "Captured Key",
            value: message.payload.value,
            notes: "Auto-captured from page",
            createdAt: (/* @__PURE__ */ new Date()).toISOString(),
            updatedAt: (/* @__PURE__ */ new Date()).toISOString(),
            isFavourite: false
          };
          defaultVault.keys.push(newKey);
          wallet.updatedAt = (/* @__PURE__ */ new Date()).toISOString();
          const keyMaterial = base64ToBuffer(derivedKey);
          const iv = crypto.getRandomValues(new Uint8Array(12));
          const aesKey = await crypto.subtle.importKey(
            "raw",
            keyMaterial,
            { name: "AES-GCM" },
            false,
            ["encrypt"]
          );
          const encoded = new TextEncoder().encode(JSON.stringify(wallet));
          const encrypted = await crypto.subtle.encrypt(
            { name: "AES-GCM", iv, tagLength: 128 },
            aesKey,
            encoded
          );
          const encBytes = new Uint8Array(encrypted);
          const ct = encBytes.slice(0, encBytes.length - 16);
          const tag = encBytes.slice(encBytes.length - 16);
          const hmacKey = await crypto.subtle.importKey(
            "raw",
            keyMaterial,
            { name: "HMAC", hash: "SHA-256" },
            false,
            ["sign"]
          );
          const ctB64 = bufferToBase64(ct.buffer);
          const sig = await crypto.subtle.sign("HMAC", hmacKey, new TextEncoder().encode(ctB64));
          await chrome.storage.local.set({
            [STORAGE_KEYS.VAULT]: {
              ...vault,
              ciphertext: ctB64,
              iv: bufferToBase64(iv.buffer),
              tag: bufferToBase64(tag.buffer),
              hmac: bufferToBase64(sig),
              updatedAt: (/* @__PURE__ */ new Date()).toISOString()
            }
          });
          lastActivity = Date.now();
        } catch (e) {
          console.error("Lockbox: failed to save captured key", e);
        }
      })();
      return true;
    case "LOCKBOX_AUTH_TOKEN":
      if (message.payload?.user) {
        chrome.storage.local.set({
          [STORAGE_KEYS.ACCOUNT]: message.payload.user
        });
      }
      break;
  }
});
chrome.runtime.onMessageExternal.addListener((message, sender, sendResponse) => {
  if (sender.url?.startsWith("https://dashboard.yourlockbox.dev")) {
    if (message.type === "LOCKBOX_AUTH_TOKEN") {
      chrome.storage.local.set({
        [STORAGE_KEYS.ACCOUNT]: message.payload?.user
      });
      sendResponse({ success: true });
    }
  }
});
chrome.commands.onCommand.addListener(async (command) => {
  if (command === "quick-copy") {
    try {
      await chrome.action.openPopup();
    } catch {
    }
  }
});
chrome.runtime.onStartup.addListener(() => {
  lastActivity = Date.now();
  updateBadge();
});
