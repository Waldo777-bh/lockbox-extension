const API_KEY_SELECTORS = [
  'input[name*="api_key" i]',
  'input[name*="apikey" i]',
  'input[name*="api-key" i]',
  'input[name*="secret_key" i]',
  'input[name*="secretkey" i]',
  'input[name*="secret-key" i]',
  'input[name*="access_token" i]',
  'input[name*="accesstoken" i]',
  'input[name*="access-token" i]',
  'input[name*="api_token" i]',
  'input[name*="bearer" i]',
  'input[name*="authorization" i]',
  'input[id*="api_key" i]',
  'input[id*="apikey" i]',
  'input[id*="api-key" i]',
  'input[id*="secret_key" i]',
  'input[id*="secretkey" i]',
  'input[id*="access_token" i]',
  'input[id*="api_token" i]',
  'input[placeholder*="api key" i]',
  'input[placeholder*="secret key" i]',
  'input[placeholder*="access token" i]',
  'input[placeholder*="api token" i]',
  'input[placeholder*="sk-" i]',
  'input[placeholder*="pk_" i]',
  'input[aria-label*="api key" i]',
  'input[aria-label*="secret key" i]',
  'input[aria-label*="token" i]',
  'textarea[name*="api_key" i]',
  'textarea[name*="secret" i]',
  'textarea[placeholder*="api key" i]',
  'textarea[placeholder*="token" i]'
];
const KEYWORD_PATTERNS = [
  /api[_-]?key/i,
  /secret[_-]?key/i,
  /access[_-]?token/i,
  /api[_-]?token/i,
  /bearer/i,
  /authorization/i,
  /api[_-]?secret/i
];
function isVisible(el) {
  const style = getComputedStyle(el);
  return style.display !== "none" && style.visibility !== "hidden" && style.opacity !== "0" && el.offsetWidth > 0 && el.offsetHeight > 0;
}
function getFieldLabel(el) {
  const attrs = [
    el.getAttribute("aria-label"),
    el.getAttribute("placeholder"),
    el.getAttribute("name"),
    el.getAttribute("id")
  ];
  for (const attr of attrs) {
    if (attr) return attr;
  }
  const id = el.getAttribute("id");
  if (id) {
    const label = document.querySelector(`label[for="${id}"]`);
    if (label) return label.textContent?.trim() || "";
  }
  return "";
}
function detectApiKeyFields() {
  const fields = [];
  const seen = /* @__PURE__ */ new Set();
  for (const selector of API_KEY_SELECTORS) {
    try {
      const elements = document.querySelectorAll(selector);
      for (const el of elements) {
        if (seen.has(el)) continue;
        if (!isVisible(el)) continue;
        seen.add(el);
        fields.push({
          element: el,
          type: el.tagName === "TEXTAREA" ? "textarea" : "input",
          confidence: "high",
          label: getFieldLabel(el)
        });
      }
    } catch {
    }
  }
  const allInputs = document.querySelectorAll(
    'input[type="text"], input[type="password"], input:not([type]), textarea'
  );
  for (const el of allInputs) {
    if (seen.has(el)) continue;
    if (!isVisible(el)) continue;
    const label = getFieldLabel(el);
    const matches = KEYWORD_PATTERNS.some((p) => p.test(label));
    if (matches) {
      seen.add(el);
      fields.push({
        element: el,
        type: el.tagName === "TEXTAREA" ? "textarea" : "input",
        confidence: "medium",
        label
      });
    }
  }
  return fields;
}
window.__lockboxDetectFields = detectApiKeyFields;

const ICON_CLASS = "lockbox-field-icon";
const PICKER_CLASS = "lockbox-key-picker";
const PROCESSED_ATTR = "data-lockbox-processed";
const PLATFORM_MAP = {
  "platform.openai.com": "openai",
  "console.anthropic.com": "anthropic",
  "dashboard.stripe.com": "stripe",
  "console.aws.amazon.com": "aws",
  "github.com": "github",
  "vercel.com": "vercel",
  "supabase.com": "supabase",
  "console.firebase.google.com": "firebase",
  "dashboard.clerk.com": "clerk",
  "railway.app": "railway",
  "console.cloud.google.com": "google_cloud",
  "dash.cloudflare.com": "cloudflare",
  "console.twilio.com": "twilio",
  "app.sendgrid.com": "sendgrid",
  "app.netlify.com": "netlify",
  "cloud.digitalocean.com": "digitalocean",
  "dashboard.heroku.com": "heroku",
  "resend.com": "resend",
  "console.neon.tech": "neon",
  "app.planetscale.com": "planetscale"
};
function getCurrentPlatform() {
  const hostname = window.location.hostname;
  for (const [domain, service] of Object.entries(PLATFORM_MAP)) {
    if (hostname === domain || hostname.endsWith("." + domain)) {
      return service;
    }
  }
  return null;
}
function createLockboxIcon() {
  const btn = document.createElement("button");
  btn.className = ICON_CLASS;
  btn.title = "Fill from Lockbox";
  btn.setAttribute("type", "button");
  btn.innerHTML = `<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#00d87a" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="11" width="18" height="11" rx="2" ry="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/></svg>`;
  return btn;
}
function positionIcon(icon, field) {
  const rect = field.getBoundingClientRect();
  icon.style.position = "absolute";
  icon.style.zIndex = "2147483647";
  icon.style.top = `${rect.top + window.scrollY + (rect.height - 24) / 2}px`;
  icon.style.left = `${rect.right + window.scrollX - 30}px`;
}
function fillField(field, value) {
  const nativeSetter = Object.getOwnPropertyDescriptor(
    field.tagName === "TEXTAREA" ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype,
    "value"
  )?.set;
  if (nativeSetter) {
    nativeSetter.call(field, value);
  } else {
    field.value = value;
  }
  field.dispatchEvent(new Event("input", { bubbles: true }));
  field.dispatchEvent(new Event("change", { bubbles: true }));
  field.dispatchEvent(new KeyboardEvent("keydown", { bubbles: true }));
  field.dispatchEvent(new KeyboardEvent("keyup", { bubbles: true }));
}
function showKeyPicker(field, icon) {
  document.querySelectorAll(`.${PICKER_CLASS}`).forEach((el) => el.remove());
  const picker = document.createElement("div");
  picker.className = PICKER_CLASS;
  const rect = icon.getBoundingClientRect();
  picker.style.position = "fixed";
  picker.style.zIndex = "2147483647";
  picker.style.top = `${rect.bottom + 4}px`;
  picker.style.left = `${Math.max(10, rect.right - 280)}px`;
  picker.innerHTML = `
    <div class="lockbox-picker-header">
      <span>Select a key</span>
      <button class="lockbox-picker-close">&times;</button>
    </div>
    <div class="lockbox-picker-loading">
      <div class="lockbox-spinner"></div>
      <span>Loading keys...</span>
    </div>
    <div class="lockbox-picker-list" style="display:none"></div>
    <div class="lockbox-picker-empty" style="display:none">
      <span>No keys found</span>
    </div>
    <div class="lockbox-picker-locked" style="display:none">
      <span>Wallet is locked. Click the Lockbox icon to unlock.</span>
    </div>
  `;
  document.body.appendChild(picker);
  picker.querySelector(".lockbox-picker-close")?.addEventListener("click", () => {
    picker.remove();
  });
  const onClickOutside = (e) => {
    if (!picker.contains(e.target) && e.target !== icon) {
      picker.remove();
      document.removeEventListener("click", onClickOutside);
    }
  };
  setTimeout(() => document.addEventListener("click", onClickOutside), 100);
  chrome.runtime.sendMessage({ type: "LOCKBOX_GET_ALL_KEYS" }, (response) => {
    if (chrome.runtime.lastError) {
      console.debug("Lockbox: could not reach background", chrome.runtime.lastError.message);
    }
    const loading = picker.querySelector(".lockbox-picker-loading");
    const list = picker.querySelector(".lockbox-picker-list");
    const empty = picker.querySelector(".lockbox-picker-empty");
    const locked = picker.querySelector(".lockbox-picker-locked");
    if (!response || response.locked) {
      loading.style.display = "none";
      locked.style.display = "flex";
      return;
    }
    let keys = response.keys || [];
    const platform = getCurrentPlatform();
    if (platform) {
      const platformKeys = keys.filter((k) => k.service === platform);
      if (platformKeys.length > 0) keys = platformKeys;
    }
    if (keys.length === 0) {
      loading.style.display = "none";
      empty.style.display = "flex";
      return;
    }
    loading.style.display = "none";
    list.style.display = "block";
    keys.slice(0, 15).forEach((key) => {
      const row = document.createElement("button");
      row.className = "lockbox-picker-row";
      row.type = "button";
      const initial = (key.service || "?")[0].toUpperCase();
      row.innerHTML = `
        <div class="lockbox-picker-icon">${initial}</div>
        <div class="lockbox-picker-info">
          <div class="lockbox-picker-name">${escapeHtml(key.name)}</div>
          <div class="lockbox-picker-service">${escapeHtml(key.service)} · ${escapeHtml(key.vaultName || "")}</div>
        </div>
      `;
      row.addEventListener("click", () => {
        fillField(field.element, key.value);
        picker.remove();
        showFillConfirmation(field.element);
      });
      list.appendChild(row);
    });
  });
}
function showFillConfirmation(field) {
  const toast = document.createElement("div");
  toast.className = "lockbox-fill-toast";
  toast.textContent = "Filled from Lockbox";
  const rect = field.getBoundingClientRect();
  toast.style.position = "fixed";
  toast.style.zIndex = "2147483647";
  toast.style.top = `${rect.top - 30}px`;
  toast.style.left = `${rect.left}px`;
  document.body.appendChild(toast);
  setTimeout(() => toast.remove(), 2e3);
}
function escapeHtml(str) {
  const div = document.createElement("div");
  div.textContent = str;
  return div.innerHTML;
}
function injectIcons() {
  const fields = detectApiKeyFields();
  for (const field of fields) {
    if (field.element.hasAttribute(PROCESSED_ATTR)) continue;
    field.element.setAttribute(PROCESSED_ATTR, "true");
    const icon = createLockboxIcon();
    document.body.appendChild(icon);
    positionIcon(icon, field.element);
    icon.addEventListener("click", (e) => {
      e.preventDefault();
      e.stopPropagation();
      showKeyPicker(field, icon);
    });
    const reposition = () => positionIcon(icon, field.element);
    window.addEventListener("scroll", reposition, { passive: true });
    window.addEventListener("resize", reposition, { passive: true });
    const observer = new MutationObserver(() => {
      if (!document.contains(field.element)) {
        icon.remove();
        observer.disconnect();
        window.removeEventListener("scroll", reposition);
        window.removeEventListener("resize", reposition);
      }
    });
    observer.observe(document.body, { childList: true, subtree: true });
  }
}
chrome.runtime.onMessage.addListener((message) => {
  if (message.type === "LOCKBOX_PASTE_KEY" && message.payload?.value) {
    const active = document.activeElement;
    if (active instanceof HTMLInputElement || active instanceof HTMLTextAreaElement) {
      fillField(active, message.payload.value);
      showFillConfirmation(active);
    }
  }
  if (message.type === "LOCKBOX_COPY_TO_CLIPBOARD" && message.payload?.value) {
    navigator.clipboard.writeText(message.payload.value).catch(() => {
    });
  }
});
function init() {
  if (!document.body) return;
  injectIcons();
  setInterval(injectIcons, 3e3);
  const observer = new MutationObserver(() => {
    injectIcons();
  });
  observer.observe(document.body, { childList: true, subtree: true });
}
if (document.readyState === "loading") {
  document.addEventListener("DOMContentLoaded", init);
} else {
  init();
}

const KEY_PATTERNS = [
  { pattern: /sk-proj-[a-zA-Z0-9_-]{20,}/, service: "openai", name: "API_KEY" },
  { pattern: /sk-ant-[a-zA-Z0-9_-]{20,}/, service: "anthropic", name: "API_KEY" },
  { pattern: /sk_test_[a-zA-Z0-9]{20,}/, service: "stripe", name: "SECRET_KEY" },
  { pattern: /sk_live_[a-zA-Z0-9]{20,}/, service: "stripe", name: "SECRET_KEY" },
  { pattern: /pk_test_[a-zA-Z0-9]{20,}/, service: "stripe", name: "PUBLISHABLE_KEY" },
  { pattern: /pk_live_[a-zA-Z0-9]{20,}/, service: "stripe", name: "PUBLISHABLE_KEY" },
  { pattern: /AKIA[A-Z0-9]{16}/, service: "aws", name: "ACCESS_KEY" },
  { pattern: /ghp_[a-zA-Z0-9]{36}/, service: "github", name: "PERSONAL_ACCESS_TOKEN" },
  { pattern: /gho_[a-zA-Z0-9]{36}/, service: "github", name: "OAUTH_TOKEN" },
  { pattern: /SG\.[a-zA-Z0-9_-]{22}\.[a-zA-Z0-9_-]{43}/, service: "sendgrid", name: "API_KEY" },
  { pattern: /re_[a-zA-Z0-9]{20,}/, service: "resend", name: "API_KEY" },
  { pattern: /dop_v1_[a-f0-9]{64}/, service: "digitalocean", name: "TOKEN" },
  { pattern: /pscale_tkn_[a-zA-Z0-9_-]{20,}/, service: "planetscale", name: "TOKEN" }
];
const CAPTURE_BAR_CLASS = "lockbox-capture-bar";
let capturedKeys = /* @__PURE__ */ new Set();
function scanForKeys() {
  const selectors = [
    "code",
    "pre",
    ".api-key",
    "[data-testid*='key']",
    "[data-testid*='token']",
    "[data-testid*='secret']",
    ".secret-key",
    ".token-value",
    "input[type='text'][readonly]",
    "input[readonly][value]",
    ".copy-text",
    "[data-clipboard-text]"
  ];
  for (const selector of selectors) {
    try {
      const elements = document.querySelectorAll(selector);
      for (const el of elements) {
        let text = "";
        if (el instanceof HTMLInputElement) {
          text = el.value;
        } else {
          text = el.textContent || "";
        }
        const clipboardText = el.getAttribute("data-clipboard-text");
        if (clipboardText) text = clipboardText;
        for (const { pattern, service, name } of KEY_PATTERNS) {
          const match = text.match(pattern);
          if (match && !capturedKeys.has(match[0])) {
            return { value: match[0], service, name };
          }
        }
      }
    } catch {
    }
  }
  return null;
}
function showCaptureBar(keyInfo) {
  if (capturedKeys.has(keyInfo.value)) return;
  capturedKeys.add(keyInfo.value);
  document.querySelectorAll(`.${CAPTURE_BAR_CLASS}`).forEach((el) => el.remove());
  const serviceName = keyInfo.service.charAt(0).toUpperCase() + keyInfo.service.slice(1);
  const bar = document.createElement("div");
  bar.className = CAPTURE_BAR_CLASS;
  bar.innerHTML = `
    <div class="lockbox-capture-content">
      <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#00d87a" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
        <rect x="3" y="11" width="18" height="11" rx="2" ry="2"/>
        <path d="M7 11V7a5 5 0 0 1 10 0v4"/>
      </svg>
      <div class="lockbox-capture-text">
        <strong>Save this API key to Lockbox?</strong>
        <span>${serviceName} ${keyInfo.name} detected</span>
      </div>
      <button class="lockbox-capture-save">Save to Lockbox</button>
      <button class="lockbox-capture-dismiss">&times;</button>
    </div>
  `;
  document.body.appendChild(bar);
  bar.querySelector(".lockbox-capture-save")?.addEventListener("click", () => {
    chrome.runtime.sendMessage(
      {
        type: "LOCKBOX_KEY_CAPTURED",
        payload: {
          service: keyInfo.service,
          name: keyInfo.name,
          value: keyInfo.value
        }
      },
      () => {
        if (chrome.runtime.lastError) {
          console.debug("Lockbox: could not save key", chrome.runtime.lastError.message);
        }
      }
    );
    bar.innerHTML = `
      <div class="lockbox-capture-content">
        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#00d87a" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
          <polyline points="20 6 9 17 4 12"/>
        </svg>
        <span style="color: #00d87a; font-weight: 500;">Saved to Lockbox!</span>
      </div>
    `;
    setTimeout(() => bar.remove(), 3e3);
  });
  bar.querySelector(".lockbox-capture-dismiss")?.addEventListener("click", () => {
    bar.remove();
  });
  setTimeout(() => {
    if (document.contains(bar)) bar.remove();
  }, 3e4);
}
function initCapture() {
  if (!document.body) return;
  const found = scanForKeys();
  if (found) showCaptureBar(found);
  const observer = new MutationObserver(() => {
    const found2 = scanForKeys();
    if (found2) showCaptureBar(found2);
  });
  observer.observe(document.body, {
    childList: true,
    subtree: true,
    characterData: true
  });
}
if (document.readyState === "loading") {
  document.addEventListener("DOMContentLoaded", initCapture);
} else {
  setTimeout(initCapture, 1e3);
}
